Welcome to Sea Pony Dash!

Credits:
	Game team:
		Programming: Jimm - jimmythetronlegacy@gmail.com
		Game Design: everyone
		Art: AnyaSmash - http://faikie.deviantart.com/
			(except for frame of sea pony facing away from screen)
		SFX: Durpy - https://soundcloud.com/durpy-1
	External assets:
		Sea Ponies intro theme: http://www.newgrounds.com/audio/listen/495279
		Celestia Medium Redux: http://www.mattyhex.net/CMR/
	